-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2024 at 09:51 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tourism_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `ACT_ID` int(11) NOT NULL,
  `ACT_NAME` varchar(30) NOT NULL,
  `P_ID` int(11) NOT NULL,
  `SPENDING_DATE` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `AP_ID` int(11) NOT NULL,
  `T_ID` int(11) NOT NULL,
  `P_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `place`
--

CREATE TABLE `place` (
  `P_ID` int(11) NOT NULL,
  `COUNTRY` varchar(30) NOT NULL,
  `PROVINCE` varchar(30) NOT NULL,
  `DISTRICT` varchar(15) NOT NULL,
  `PLACE_NAME` varchar(30) NOT NULL,
  `PRICE` varchar(10) NOT NULL,
  `DATE_OF_VISIT` date NOT NULL,
  `DESCRIPTION` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `place`
--

INSERT INTO `place` (`P_ID`, `COUNTRY`, `PROVINCE`, `DISTRICT`, `PLACE_NAME`, `PRICE`, `DATE_OF_VISIT`, `DESCRIPTION`) VALUES
(1, 'egypt', 'west', 'rutsiro', 'nyungwe', '2000', '2024-02-02', 'gehjfkds'),
(2, 'uganda', 'wewe', 'wewe', 'wewe', '232', '2016-02-10', '23wedsefds'),
(4, 'usa', 'los', 'texas', 'sss', '2222', '2024-01-04', 'we visit'),
(12, 'America', 'west', 'rutsiro', 'nyungwe', '2000', '2024-02-02', 'gehjfkds'),
(13, 'BURUNDI', 'KIBITOKI', 'aa', '0000000000', '123', '2024-02-07', 'we give you besst services');

-- --------------------------------------------------------

--
-- Table structure for table `tourist`
--

CREATE TABLE `tourist` (
  `T_id` int(11) NOT NULL,
  `FIRST_NAME` varchar(50) NOT NULL,
  `LAST_NAME` varchar(30) NOT NULL,
  `EMAIL` varchar(30) NOT NULL,
  `PHONE` varchar(13) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tourist`
--

INSERT INTO `tourist` (`T_id`, `FIRST_NAME`, `LAST_NAME`, `EMAIL`, `PHONE`, `PASSWORD`) VALUES
(1, 'z', 'z', 'z', 'z', 'z'),
(2, 'x', 'x', 'x', 'x', 'x'),
(3, 'xx', 'xx', 'xx', 'xx', 'xx'),
(4, 's', 's', 's', 's', 's'),
(5, 'sam', 'ndatimana', 'sam@gmail.com', '078', '123'),
(6, 'x', 'x', 'x', 'x', 'x'),
(7, 's', 's', 's', 's', 's'),
(8, 'NDATIMANA', 'Samuel', 'samsadiva@gmail.com', '+250782154032', '12345'),
(9, 'NDATIMANA', 'samuel', 'samuel', '0782154032', '222017085');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`ACT_ID`),
  ADD KEY `ACT_NAME` (`ACT_NAME`),
  ADD KEY `P_ID` (`P_ID`);

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD KEY `T_ID` (`T_ID`),
  ADD KEY `P_ID` (`P_ID`);

--
-- Indexes for table `place`
--
ALTER TABLE `place`
  ADD PRIMARY KEY (`P_ID`);

--
-- Indexes for table `tourist`
--
ALTER TABLE `tourist`
  ADD PRIMARY KEY (`T_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `ACT_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `place`
--
ALTER TABLE `place`
  MODIFY `P_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tourist`
--
ALTER TABLE `tourist`
  MODIFY `T_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity`
--
ALTER TABLE `activity`
  ADD CONSTRAINT `activity_ibfk_1` FOREIGN KEY (`P_ID`) REFERENCES `place` (`P_ID`);

--
-- Constraints for table `application`
--
ALTER TABLE `application`
  ADD CONSTRAINT `application_ibfk_1` FOREIGN KEY (`T_ID`) REFERENCES `tourist` (`T_id`),
  ADD CONSTRAINT `application_ibfk_2` FOREIGN KEY (`P_ID`) REFERENCES `place` (`P_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
